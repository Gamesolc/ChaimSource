package tk.gamesolc.chaim;

import android.content.Context;
import android.widget.Toast;

public class EasyToast{
        public static class Long{
            public static void Failed(Context ctext, String text){
                Toast.makeText(ctext, text, Toast.LENGTH_LONG);
            }
        }
    }
