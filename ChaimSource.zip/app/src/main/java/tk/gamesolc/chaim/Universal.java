package tk.gamesolc.chaim;

import android.app.Activity;
import android.content.Intent;
import android.widget.EditText;

import com.google.android.gms.auth.api.signin.GoogleSignInAccount;

/**
 * Created by liammendes on 24/09/2016.
 */
public class Universal {

    public static String EXTRA_MESSAGE = null;
    public static PrefManager PM;

    public Universal(){

    }

    public static void setExtraMessage(String ExtraMessage){
        EXTRA_MESSAGE = ExtraMessage;

    }
    public void showChatHubUI(Activity activity, GoogleSignInAccount acct) {
        Intent intent = new Intent(activity, FriendsHub.class);
        intent.putExtra(EXTRA_MESSAGE, acct.getEmail() + "," + acct.getDisplayName() + "," + acct.getPhotoUrl());
        if((PM = new PrefManager(activity)).isFirstTimeLaunch() == true){
            PM.setFirstTimeLaunch(false);
            Intent introIntent = new Intent(activity, WelcomeActivity.class);
            introIntent.putExtra(EXTRA_MESSAGE, acct.getDisplayName() + "," + acct.getDisplayName() + "," + acct.getPhotoUrl());
            this.startIntro(activity, intent, introIntent);
            return;
        }
        activity.startActivity(intent);
    }

    private void startIntro(Activity activity, Intent intent, Intent introIntent) {
        activity.startActivity(introIntent);
        activity.startActivity(intent);
    }

    public static class Build {
        public static Object[] firebaseAuthenticate(String EXTRA_MESSAGE){

            Object[] object = {new Universal(), EXTRA_MESSAGE};
            return object;
        }

    }
}
