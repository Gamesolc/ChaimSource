package tk.gamesolc.chaim;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class FriendsHub extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends_hub);

        Data d = getData(getIntent(), MainActivity.EXTRA_MESSAGE); String email = d.getEmail(); String photo = d.getPhoto(); String displayName = d.getDisplayName();

    }

    private Data getData(Intent intent, String extraMessage) {
        Data data = new Data(intent.getStringExtra(extraMessage)).parseData();
        return data;
    }


}
