package tk.gamesolc.chaim;

/**
 * Created by liammendes on 25/09/2016.
 */
public class Data {

    private String Email;
    private String DisplayName;
    private String PictureURL;
    private String stringExtra;
    public Data(String stringExtraData) {
        stringExtra = stringExtraData;
    }

    public String getEmail() {
        return Email;
    }

    public String getPhoto() {
        return PictureURL;
    }

    public String getDisplayName() {
        return DisplayName;
    }

    public Data parseData() {
        if(stringExtra == null){
            return null;
        } else {
            String[] data = stringExtra.split(",");
            Email = data[0];
            DisplayName = data[1];
            PictureURL = data[2];
            return this;
        }
    }
}
